import React from "react";
import { Phone, MapPin, Send } from "lucide-react";

export default function RonakPharmaSite() {
  const products = [
    "A TO Z TAB", "ABANA", "ACILOC 300 TAB", "ACNESTAR GEL", "ADLIV SYP", "ALERID TAB",
    "ALLEGRA 120 TAB", "ALMOX CAP 250", "AMARYL M1 TAB", "AMPILOX 500 CAP", "AMTAS AT TAB",
    "ASCORIL LS SYP", "ASTHALIN INHALER", "AUGMENTIN 625 TAB", "AZEE 500TAB",
    "BECOSULES Z CAP", "BENADRYL 150ML SYP", "BETADINE POWDER", "CANDID POWDER 60GM",
    "CIPLOX 500 TAB", "COMBIFLAM TAB", "CROCIN 650MG TAB", "CYRA 20 TAB",
    "DEXORANGE SYP", "DOLO-650MG TAB", "DROTIN DS TAB", "ELTROXIN 100 mcg TAB",
    "GLYCIPHAGE 500 TAB", "GRILINCTUS SYP", "LIV 52 DS TAB", "MEFTAL SPAS TAB",
    "NEUROBION FORTE TAB", "NISE TAB", "OMNACORTIL 5 TAB", "PANTOP D CAP",
    "SINAREST TAB", "TUSQ DX SYP", "ZIFI 200 TAB", "ZINCOVIT TAB"
  ];

  return (
    <div className="font-sans text-gray-800">
      {/* Header */}
      <header className="bg-green-700 text-white p-4 sticky top-0 shadow z-10">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">RONAK PHARMA</h1>
          <p className="italic text-sm">OK रेट ! OK वैरायटी !</p>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-green-100 py-10">
        <div className="max-w-6xl mx-auto text-center px-4">
          <h2 className="text-3xl font-bold mb-2">Wholesaler of Running Medicines</h2>
          <p className="text-lg mb-4">Serving Aligarh with quality and variety at the best rates.</p>
          <a
            href="https://wa.me/919319488088"
            className="inline-flex items-center bg-green-600 text-white px-5 py-2 rounded-full shadow hover:bg-green-700 transition"
          >
            <Send className="mr-2 w-4 h-4" /> WhatsApp Us
          </a>
        </div>
      </section>

      {/* About Section */}
      <section className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h3 className="text-2xl font-semibold mb-4">About Us</h3>
          <p className="text-md text-gray-700">
            At Ronak Pharma, we specialize in supplying running medicines to pharmacies and medical retailers at wholesale rates.
            Our commitment is simple: excellent pricing, unmatched variety, and reliable service. Based in Aligarh, we pride ourselves
            on building long-term relationships with our clients.
          </p>
          <p className="text-md text-gray-700 mt-4">
            <strong>Paatshah Trading Company</strong> is a major subsidiary of Ronak Pharma, contributing to our extended distribution
            and wholesale capabilities across pharmaceutical categories. Together, we ensure seamless supply and expanded product access
            for our customers.
          </p>
        </div>
      </section>

      {/* Product Section */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h3 className="text-2xl font-semibold mb-6">Popular Products</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-left text-sm">
            {products.map((product, index) => (
              <div key={index} className="bg-white p-3 rounded shadow">
                {product}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Download Product List */}
      <section className="py-6 bg-white text-center">
        <div className="max-w-4xl mx-auto px-4">
          <h3 className="text-xl font-semibold mb-4">Download Full Product List</h3>
          <a
            href="/ronak_pharma_product_list.pdf"
            download
            className="inline-block bg-green-600 text-white px-6 py-3 rounded-lg shadow hover:bg-green-700 transition"
          >
            Download PDF
          </a>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-12 bg-white">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h3 className="text-2xl font-semibold mb-6">Our Services</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-50 p-6 rounded-xl shadow">
              <h4 className="font-bold mb-2">Bulk Medicine Supply</h4>
              <p>Timely delivery of high-demand medicines at wholesale rates.</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-xl shadow">
              <h4 className="font-bold mb-2">Trusted Quality</h4>
              <p>Only genuine, verified pharmaceutical products.</p>
            </div>
            <div className="bg-gray-50 p-6 rounded-xl shadow">
              <h4 className="font-bold mb-2">Local Support</h4>
              <p>Personalized assistance for businesses in Aligarh and nearby regions.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-12 bg-green-100">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h3 className="text-2xl font-semibold mb-4">Contact Us</h3>
          <p className="mb-2 flex justify-center items-center">
            <Phone className="mr-2" /> 9319488088 / 7454837540
          </p>
          <p className="mb-2 flex justify-center items-center">
            <MapPin className="mr-2" /> Shop No.2, Simra Complex, Phaphala Street, Aligarh
          </p>
          <p className="mt-4 italic">एक बार ऑर्डर लिखवाके देखिए</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-green-700 text-white text-center py-4">
        <p>&copy; {new Date().getFullYear()} RONAK PHARMA. All rights reserved. <br /> In partnership with Paatshah Trading Company</p>
      </footer>
    </div>
  );
}
